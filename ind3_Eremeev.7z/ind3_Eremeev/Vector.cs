﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ind3_Eremeev
{
    internal class Vector
    {
        private double[] vector = new double[3];

        public Vector() { }

        public Vector(double x, double y, double z)
        {
            vector[0] = x;
            vector[1] = y;
            vector[2] = z;
        }

        public double[] GetCoordinates
        {
            get { return vector; }
            set { vector = value; }
        }

        public Vector Vectordo(bool isAddition, Vector vectorwan, Vector vectortwo)
        {
            Vector vector;

            double[] vect = new double[3];
            int sign = isAddition ? 1 : -1;

            vect[0] = vectorwan.vector[0] + (vectortwo.vector[0] * sign);
            vect[1] = vectorwan.vector[1] + (vectortwo.vector[1] * sign);
            vect[2] = vectorwan.vector[2] + (vectortwo.vector[2] * sign);

            vector = new Vector(vect[0], vect[1], vect[2]);

            return vector;
        }

        public double Product(Vector vector)
        {
            return Math.Round(this.vector[0] * vector.vector[0] + this.vector[1] * vector.vector[1]
                + this.vector[2] * vector.vector[2], 2);
        }

        public double Metod()
        {
            return Math.Round(Math.Sqrt(Math.Pow(vector[0], 2) + Math.Pow(vector[1], 2) + Math.Pow(vector[2], 2)), 2);
        }

        public double Cos(Vector vector)
        {
            double product = Product(vector);
            double metod = this.Metod() * vector.Metod();

            if (metod == 0)
            {
                throw new InvalidOperationException("error");
            }
            else
                return Math.Round(product / metod, 2);
        }
    }
}
