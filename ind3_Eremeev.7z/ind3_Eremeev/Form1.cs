﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ind3_Eremeev
{
    public partial class Form1 : Form
    {
        Vector vectorA;
        Vector vectorB;
        Vector vectorC;

        ArrayList vectors = new ArrayList();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private Vector VvodVectora(string xText, string yText, string zText)
        {
            if (double.TryParse(xText, out double x) && double.TryParse(yText, out double y)
                && double.TryParse(zText, out double z))
            {
                MessageBox.Show("Вектор добавлен", "Операция успешна");
                return new Vector(x, y, z);
            }
            else
            {
                MessageBox.Show("Не удалось преобразовать координаты в double", "Ошибка преобразования");
                return null;
            }
        }


        private void addVectorA_Click(object sender, EventArgs e)
        {
            vectorA = VvodVectora(textbox1.Text, textbox2.Text, textbox3.Text);
        }
        private void addVectorB_Click(object sender, EventArgs e)
        {
            vectorB = VvodVectora(textbox4.Text, textbox5.Text, textbox6.Text);
        }

        private void solveVestorC_Click(object sender, EventArgs e)
        {
            vectors.Clear();
            listBox1.Items.Clear();
          if (vectorA!=null&vectorB!=null)
          {
            
            vectorC = new Vector();

            vectorC = vectorC.Vectordo(checkbox1.Checked, vectorA, vectorB);
                listBox1.Items.Clear();
                if (vectorC != null)
           {
                    listBox1.Items.Clear();
                vectors.Add(vectorA);
                vectors.Add(vectorB);
                vectors.Add(vectorC);

                foreach (Vector vector in vectors)
                {
                    listBox1.Items.Add($"Координаты вектора: ({vector.GetCoordinates[0]}, " +
                        $"{vector.GetCoordinates[1]}, " +
                        $"{vector.GetCoordinates[2]})");
                }

                listBox1.Items.Add($"Скалярное произведение: {vectorA.Product(vectorB)}");
                listBox1.Items.Add($"Длина вектора А: {vectorA.Metod()}");
                listBox1.Items.Add($"Длина вектора А: {vectorB.Metod()}");
                listBox1.Items.Add($"Косинус между векторами А и Б: {vectorA.Cos(vectorB)}");
            }
            else
            {
                MessageBox.Show("Не удалось преобразовать введеные поля в double");
            }
          }
          else
          {
              MessageBox.Show("Введите Вектор А и вектор В");
          }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
